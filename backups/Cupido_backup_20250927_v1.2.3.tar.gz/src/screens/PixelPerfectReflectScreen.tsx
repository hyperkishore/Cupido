import React from 'react';
import { ChatReflectionInterface } from '../components/ChatReflectionInterface';

export const PixelPerfectReflectScreen = () => {
  return <ChatReflectionInterface />;
};